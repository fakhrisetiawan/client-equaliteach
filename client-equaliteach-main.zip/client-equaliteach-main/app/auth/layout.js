export const metadata = {
  title: "EQUALITEACH",
};

export default function RootLayout({ children }) {
  return <div className="wrapper">{children}</div>;
}
